chrome-social-media-share
=========================

A chrome extension which enables sharing the current URL on various social media platforms.
